CyberPatriot Interactive Demonstration version 1.0.0

Welcome to the CyberPatriot Interactive Demonstration!
------------------------------------------------------

-CyberPatriot is the National Youth Cyber Education Program created by the
 Air Force Association to inspire K-12 students toward careers in cybersecurity
 or other science, technology, engineering, and mathematics (STEM) disciplines
 critical to our nation's future. At the core of the program is the National
 Youth Cyber Defense Competition, the nation's largest cyber defense competition
 that puts high school and middle school students in charge of securing virtual
 machines and networks.

-The goal of this software is to provide you with a hands-on demonstration
 of a segment of the CyberPatriot National Youth Cyber Defense Competition.
---------------------------------------------------------------------------------

Minimum System Requirements:

OS: 64-bit Windows 7 or higher
Processor: Intel Core i5-3570K or AMD FX-8310
Video Card: NVIDIA GeForce GTX 260
Free Disk Space: 1 GB
RAM: 2 GB 
----------------------------------------------

Launch Instructions:

-There are two folders, each containing a game with a different resolution or
 screen size. The two resolutions are 1440 x 810 and Full Screen.
-Open the folder that includes the screen size of your choice.
-Double click the application titled "CyberPatriot Interactive Demo."
-For the application to launch the following files and folders are required:

-CyberPatriot Interactive Demo_Data
-MonoBleedingEdge
-UnityCrashHandler32
-CyberPatriot Interactive Demo
-UnityCrashHandler32
-UnityPlayer.dll

-If any of the files or folders are missing you must download the whole package.

----------------------------------------------

The CCS Competition System is the property of the Air Force Association
and the University of Texas at San Antonio.

All Rights Reserved.